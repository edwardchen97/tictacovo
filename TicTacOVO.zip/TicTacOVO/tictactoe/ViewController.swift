//
//  ViewController.swift
//  tictactoe
//
//  Created by Edward Chen on 2017-06-28.
//  Copyright © 2017 booLEAN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var winnerLabel: UILabel!
    @IBOutlet var winnerImage: UIImageView!
    @IBOutlet var playAgainButton: UIButton!
    
    @IBAction func playAgain(_ sender: Any) {
        
        activeGame = true
        
        player = 1
        
        gameState = [0, 0, 0, 0, 0, 0, 0, 0, 0]
        
        for i in 1..<10{

            if let button = view.viewWithTag(i) as? UIButton{
                
                button.setImage(nil, for: [])
            }
            
        }
        
        winnerLabel.isHidden = true
        playAgainButton.isHidden = true
        winnerImage.isHidden = true
        
        winnerLabel.center = CGPoint(x: winnerLabel.center.x - 500, y: winnerLabel.center.y)
        
        playAgainButton.center = CGPoint(x: playAgainButton.center.x - 500, y: playAgainButton.center.y)
        
        winnerImage.center = CGPoint(x: winnerImage.center.x - 510, y: winnerImage.center.y)
        
    }
    var activeGame = true
    
    var player = 1
    
    var gameState = [0, 0, 0, 0, 0, 0, 0, 0, 0]
    
    let winningCombo = [[0,1,2], [3,4,5], [6,7,8], [0,3,6], [1,4,7], [2,5,8], [0,4,8], [2,4,6]]
    
    let drakeLines = ["Is that a world tour or your girl's tour?", "Back to back like Jordan '96 '97", "You gon' make me buy bottles for Charlamagne", "Trigger fingers turn to twitter fingers", "Hit 'em with prenup", "Golden State running practice at my house", "Ye's pool is nice, mine's just bigger's what I'm saying", "I hate a goofy especially", "Jealousy is just love and hate at the same time"]
    let meekLines = ["You really sweet, I call you buttercup", "Who was Quentin running through the six with?", "I just wanna know", "They don't want to see the Wraith", "Pull up on her fast as Uber in that Wraith", "I put everything in motion like I-N-G", "Hold up wait a minute, y'all thought I was finished?", "When I bought that Aston Martin, y'all thought it was rented?"]
    
    
    @IBAction func gridImage(_ sender: Any) {
        
        let activePosition = (sender as AnyObject).tag - 1
        
        if gameState[activePosition] == 0 && activeGame{
            
            gameState[activePosition] = player
            
            if player == 1{
                
                (sender as AnyObject).setImage(UIImage(named: "drake.jpg"), for: [])
                
                player = 2
                
            }else{
                
                (sender as AnyObject).setImage(UIImage(named: "meek.png"), for: [])
                
                player = 1
            }
            
            for combo in winningCombo{
                
                if gameState[combo[0]] != 0 && gameState[combo[0]] == gameState[combo[1]] && gameState[combo[1]] == gameState[combo[2]]{
                    
                    activeGame = false
                    
                    winnerLabel.isHidden = false
                    
                    winnerImage.isHidden = false
                    
                    playAgainButton.isHidden = false
                    
                    if gameState[combo[0]] == 1{
                        
            
                        winnerLabel.text = drakeLines[Int(arc4random_uniform(UInt32(drakeLines.count)))]
                        
                        winnerImage.image = UIImage(named: "drakelaugh.png")
                    } else{
                        
                        
                        winnerLabel.text = meekLines[Int(arc4random_uniform(UInt32(meekLines.count)))]
                        
                        winnerImage.image = UIImage(named: "meek2.png")
                    }
                    
                    UIView.animate(withDuration: 1, animations: {
                        
                        self.winnerLabel.center = CGPoint(x: self.winnerLabel.center.x + 500, y: self.winnerLabel.center.y)
                        
                        self.playAgainButton.center = CGPoint(x: self.playAgainButton.center.x + 500, y: self.playAgainButton.center.y)
                        
                        self.winnerImage.center = CGPoint(x: self.winnerImage.center.x + 510, y: self.winnerImage.center.y)
                    })
                    
                }
            }
            
            
            if gameState[0] != 0 && gameState[1] != 0 && gameState[2] != 0 && gameState[3] != 0 && gameState[4] != 0 && gameState[5] != 0 && gameState[6] != 0 && gameState[7] != 0 && gameState[8] != 0 {
                
                activeGame = false
                
                winnerLabel.isHidden = false
                
                playAgainButton.isHidden = false
                
                
                winnerLabel.text = "It's a tie ting"
                
                UIView.animate(withDuration: 1, animations: {
                    
                    self.winnerLabel.center = CGPoint(x: self.winnerLabel.center.x + 500, y: self.winnerLabel.center.y)
                    
                    self.playAgainButton.center = CGPoint(x: self.playAgainButton.center.x + 500, y: self.playAgainButton.center.y)
                    
                })
            }
        }
        
    }
        
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        winnerLabel.isHidden = true
        playAgainButton.isHidden = true
        winnerImage.isHidden = true
        
        winnerLabel.center = CGPoint(x: winnerLabel.center.x - 500, y: winnerLabel.center.y)
        
        playAgainButton.center = CGPoint(x: playAgainButton.center.x - 500, y: playAgainButton.center.y)
        
        winnerImage.center = CGPoint(x: winnerImage.center.x - 500, y: winnerImage.center.y)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

